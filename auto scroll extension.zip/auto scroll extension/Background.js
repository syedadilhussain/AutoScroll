// Called when the user clicks on the extension's icon
chrome.browserAction.onClicked.addListener(function(tab) {
  // Toggle the active state of the extension
  chrome.tabs.sendMessage(tab.id, { action: "toggleScroll" });
});

// Listen for messages from content scripts
chrome.runtime.onMessage.addListener(function(message, sender, sendResponse) {
  if (message.action === "getScrollState") {
    // Get the current scroll state of the active tab
    chrome.tabs.sendMessage(sender.tab.id, { action: "scrollState" }, function(response) {
      sendResponse(response);
    });
    return true; // Allow asynchronous response
  }
});
