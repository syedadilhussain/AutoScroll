// Listen for messages from the background script
chrome.runtime.onMessage.addListener(function(message, sender, sendResponse) {
  if (message.action === "toggleScroll") {
    toggleScroll();
  } else if (message.action === "scrollState") {
    sendResponse({ scrolling: isScrolling() });
  }
});

// Toggle the scrolling functionality
function toggleScroll() {
  if (isScrolling()) {
    stopScrolling();
  } else {
    startScrolling();
  }
}

// Start scrolling the web page
function startScrolling() {
  scrollToBottom();
  setInterval(scrollToBottom, 2000); // Change the interval as per your needs
}

// Stop scrolling the web page
function stopScrolling() {
  clearInterval();
}

// Check if the web page is currently scrolling
function isScrolling() {
  // Implement your logic here to check if scrolling is currently active
  // For example, you can check if an interval is currently running or if the page is being scrolled by the user
  return false;
}

// Scroll the web page to the bottom
function scrollToBottom() {
  window.scrollTo(0, document.body.scrollHeight);
}
